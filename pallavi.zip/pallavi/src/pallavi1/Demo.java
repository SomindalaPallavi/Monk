package pallavi1;
import java.util.*;
public class Demo {

	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		al.add(10);
		al.add(20);
		al.add(30);
        System.out.println(al);
		for(int i=0;i<al.size();i++)
		{
			System.out.print((int)al.get(i) +1 + " ");
		}

	}

}
